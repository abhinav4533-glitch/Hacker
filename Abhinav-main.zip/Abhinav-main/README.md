# 3d-portfolio

Personal Portfolio website designed using ThreeJS

Install Dependencies

```sh
npm install
```

Start the development server

```sh
npm run dev
```

Preview: kingisback45/Abhinav
